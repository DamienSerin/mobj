// -*- explicit-buffer-name: "Point.cpp<M1-MOBJ/4-5>" -*-

#include "Point.h"
#include "Cell.h"

namespace Netlist {

  using namespace std;


}  // Netlist namespace.
